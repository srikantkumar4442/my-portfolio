const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});

mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

const typingText = document.getElementById("typingText");
const phrases = ["Building for the web.", "Learning by creating.", "Turning ideas into code."];
let phraseIndex = 0;

setInterval(() => {
  phraseIndex = (phraseIndex + 1) % phrases.length;
  typingText.textContent = phrases[phraseIndex];
}, 2600);
