# Srikant Kumar — Developer Portfolio

## Files
- `index.html` — website structure and content
- `style.css` — colours, layout, responsive design and animations
- `script.js` — mobile navigation, current year and rotating hero text
- `banner.png` — your welcome banner image

## Run locally
1. Extract the ZIP file.
2. Open the `srikant_professional_portfolio` folder in VS Code.
3. Open `index.html` in your browser (or use the VS Code Live Server extension).

## Before publishing
- Your supplied email and phone number are linked in the Contact section. Think carefully before publishing a personal phone number publicly.
- Replace the sample project cards with links and details for your real projects.
- Check all personal details before publishing the website publicly.

The website uses Google Fonts; if you are offline, it falls back to system fonts.
